/**
 * Contact class represents a single contact record in the system.
 * All fields except contactId are updatable based on system requirements.
 * Validation rules are applied to ensure data integrity.
 */
public class Contact {
    
    // Contact ID is final, required, not null, max 10 characters, and cannot be changed
    private final String contactId;

    // Updatable fields with specific validation rules
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Constructor initializes and validates all values for a new Contact.
     */
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Contact ID must not be null and must be 10 characters or less.");
        }
        this.contactId = contactId;

        // Use setters to enforce existing validation logic
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    // Getters (no setter for contactId due to immutability requirement)
    public String getContactId() { return contactId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }

    /**
     * Updates firstName if value is valid.
     */
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("First name must not be null and must be 10 characters or less.");
        }
        this.firstName = firstName;
    }

    /**
     * Updates lastName if value is valid.
     */
    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Last name must not be null and must be 10 characters or less.");
        }
        this.lastName = lastName;
    }

    /**
     * Updates phone number if value is exactly 10 characters.
     */
    public void setPhone(String phone) {
        if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Phone number must be exactly 10 digits.");
        }
        this.phone = phone;
    }

    /**
     * Updates address if value is valid.
     */
    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Address must not be null and must be 30 characters or less.");
        }
        this.address = address;
    }
}
