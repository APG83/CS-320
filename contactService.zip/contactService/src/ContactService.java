import java.util.HashMap;
import java.util.Map;

/**
 * ContactService manages Contact objects using an in-memory data structure.
 * This service supports adding, updating, and deleting contact records.
 */
public class ContactService {

    // Map used to store contacts using contactId as the unique identifier
    private Map<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a new Contact object if the contactId does not already exist.
     * @return true if successfully added, false if duplicate
     */
    public boolean addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            return false; // Duplicate ID not allowed
        }
        contacts.put(contact.getContactId(), contact);
        return true;
    }

    /**
     * Deletes a contact by contactId if it exists.
     * @return true if successfully deleted, false if not found
     */
    public boolean deleteContact(String contactId) {
        return contacts.remove(contactId) != null;
    }

    /**
     * Updates an existing contact's updatable fields.
     * Null values are ignored to allow partial updates.
     * @return true if contact found and updated, false if not found
     */
    public boolean updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            return false; // No contact found for given ID
        }

        // Only update fields that are not null
        if (firstName != null) contact.setFirstName(firstName);
        if (lastName != null) contact.setLastName(lastName);
        if (phone != null) contact.setPhone(phone);
        if (address != null) contact.setAddress(address);

        return true;
    }
}
